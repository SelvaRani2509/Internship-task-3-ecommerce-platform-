const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const db = require('./database');

const app = express();
const PORT = 3001;

app.use(cors());
app.use(bodyParser.json());

// 1. USERS
app.get('/users', (req, res) => {
    const sql = "SELECT * FROM users";
    db.all(sql, [], (err, rows) => {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json(rows);
    });
});

// 2. CATEGORIES
app.get('/categories', (req, res) => {
    const sql = "SELECT * FROM categories";
    db.all(sql, [], (err, rows) => {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json(rows);
    });
});

// 3. PRODUCTS
// Get All
app.get('/products', (req, res) => {
    const sql = "SELECT * FROM products";
    db.all(sql, [], (err, rows) => {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json(rows);
    });
});

// Get Single Product
app.get('/products/:id', (req, res) => {
    const sql = "SELECT * FROM products WHERE id = ?";
    db.get(sql, req.params.id, (err, row) => {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json(row);
    });
});

// Add Product
app.post('/products', (req, res) => {
    const { id, name, category, price, rating, description, image } = req.body;
    const sql = "INSERT INTO products (id, name, category, price, rating, description, image) VALUES (?,?,?,?,?,?,?)";
    const params = [id, name, category, price, rating, description, image];
    db.run(sql, params, function (err) {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json({
            "message": "success",
            "data": req.body
        });
    });
});

// Update Product
app.put('/products/:id', (req, res) => {
    const { name, category, price, rating, description, image } = req.body;
    const sql = `UPDATE products SET 
                 name = COALESCE(?,name), 
                 category = COALESCE(?, category),
                 price = COALESCE(?, price),
                 rating = COALESCE(?, rating),
                 description = COALESCE(?, description),
                 image = COALESCE(?, image)
                 WHERE id = ?`;
    const params = [name, category, price, rating, description, image, req.params.id];
    db.run(sql, params, function (err) {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json({
            message: "success",
            changes: this.changes
        });
    });
});

// Delete Product
app.delete('/products/:id', (req, res) => {
    const sql = "DELETE FROM products WHERE id = ?";
    db.run(sql, req.params.id, function (err) {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json({ "message": "deleted", changes: this.changes });
    });
});

// 4. DELIVERY PERSONS
app.get('/deliveryPersons', (req, res) => {
    const sql = "SELECT * FROM deliveryPersons";
    db.all(sql, [], (err, rows) => {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json(rows);
    });
});

// 5. ORDERS
// Get All
app.get('/orders', (req, res) => {
    const sql = "SELECT * FROM orders";
    db.all(sql, [], (err, rows) => {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        // Parse items back to JSON
        const orders = rows.map(order => ({
            ...order,
            items: JSON.parse(order.items || '[]')
        }));
        res.json(orders);
    });
});

// Create Order
app.post('/orders', (req, res) => {
    const { id, customerName, phone, address, items, total, status, placedAt } = req.body;
    // Generate an ID if not provided (though frontend usually generates it)
    const orderId = id || Math.random().toString(36).substr(2, 9);

    const sql = "INSERT INTO orders (id, customerName, phone, address, items, total, status, placedAt) VALUES (?,?,?,?,?,?,?,?)";
    const params = [orderId, customerName, phone, address, JSON.stringify(items), total, status, placedAt];

    db.run(sql, params, function (err) {
        if (err) {
            res.status(400).json({ "error": err.message });
            return;
        }
        res.json({
            "message": "success",
            "data": { ...req.body, id: orderId }
        });
    });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
